import Headers from './components/Headers';
import Home from './components/Home';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import CartDetails from './components/CartDetails';
import {Routes,Route} from 'react-router-dom'
import toast, { Toaster } from 'react-hot-toast';

function App() {
  return (
    <>
    <Headers/>
    <Routes>
      <Route path='/' element={<Home></Home>} ></Route>
      <Route path='/cart' element={<CartDetails></CartDetails>} ></Route>
    </Routes>
    <Toaster />
    </>
  );
}

export default App;
