import {createSlice} from '@reduxjs/toolkit'

const initialState={
    carts:[]
}

//card slice

const cartSlice=createSlice({
    name:"cartslice",
    initialState,
    reducers:{
        //add to cart
        addToCart:(state,action)=>{
           
          const itemIndex=state.carts.findIndex((item)=>item.id===action.payload.id)
          console.log(itemIndex)
          if(itemIndex>=0){
            state.carts[itemIndex].qnty+=1
          }else{
            const temp={...action.payload,qnty:1}
            state.carts=[...state.carts,temp]
          }

             
        },
        //remove from cart
        removeToCart:(state,action)=>{
           const data =state.carts.filter((element)=>element.id!==action.payload)
            state.carts=data

        },
        //remove single items
        removeSingleItems:(state,action)=>{
            const itemIndex_dec=state.carts.findIndex((item)=>item.id===action.payload.id)
            if(state.carts[itemIndex_dec].qnty>=1){
                state.carts[itemIndex_dec].qnty-=1
            }
        },
        //clear cart
        emptyCart:(state,action)=>{
            state.carts=[]
        }
    }
});

export const { addToCart,removeToCart,removeSingleItems,emptyCart} = cartSlice.actions;

export default cartSlice.reducer;

// export const {addToCart}=cartSlice.actions;

// export default cartSlice.reducer;














